﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Services.RepositoryPattern.Movie;
using Domain.Entities;
using DataAccessLayer.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : BaseController
    {
        private readonly IMovie _Movies;
        public MoviesController (IMovie m)
        {
            _Movies = m;
        }
        [HttpGet]
        public Task<List<TblMovies>> Index()
        {

            return _Movies.GetMovies();
            //return View();
        }
        [HttpPost]
        public Task<string> Add([FromBody] MoviesModel m)
        {
            return _Movies.AddSync(m);
        }
        [HttpPost]
        public Task<string> Update([FromBody] MoviesModel m)
        {
            return _Movies.UpdateSync(m);
        }
        [HttpPost]
        public Task<string> Remove(int ID)
        {
            return _Movies.RemoveSync(ID);
        }
        [HttpPost]
        public Task<string> Activate(int ID)
        {
            return _Movies.RemoveSync(ID);
        }
        [HttpPost]
        public Task<string> AddRating(int ID,int Rating)
        {
            return _Movies.AddRating(ID, Rating);
        }
        [HttpGet]
        public Task<decimal> GetRating(int ID)
        {
            return _Movies.GetRating(ID);
        }
        [HttpGet]
        public Task<List<RatingDetail>> GetRatingDetails(int ID)
        {
            return _Movies.GetRatingDetails(ID);
        }

    }
}
